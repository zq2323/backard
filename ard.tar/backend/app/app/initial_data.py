import asyncio
import logging

from app.core.database.init_db import init_db
from app.core.session import SessionLocal

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def init():
    db = SessionLocal()
    await init_db(db)


async def main_migration():
    logger.info("Creating initial data")
    await init()
    logger.info("Initial data created")


if __name__ == "__main__":
    asyncio.run(main_migration())
