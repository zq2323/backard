import logging
import os
from configparser import ConfigParser
from functools import lru_cache
import secrets
import base64
from cryptography.fernet import Fernet
import fire

# Generate a secure encryption key and initialize Fernet
# encryption_key = Fernet.generate_key()
from app.core.utility.utils import is_base64_encoded, decrypt, encrypt

encryption_key = os.environ.get('ENCRYPTION_KEY')

cipher_suite = Fernet(encryption_key)


logger = logging.getLogger(__name__)

CONF_FILES = {
    'dev': 'dev.ini',
    'int': 'int.ini',
    'uat': 'uat.ini',
    'prod': 'prod.ini'
}

values_to_encrypt = [
    {'section': 'database', 'key': 'POSTGRES_PASSWORD'},
    # {'section': 'admin', 'key': 'FIRST_SUPERUSER_PASSWORD'},

    # {'section': 'admin', 'keycloak': 'CLIENT_ID'},
    # {'section': 'admin', 'keycloak': 'CLIENT_SECRET'},
]


# Function to read a configuration file and return a ConfigParser object.
@lru_cache(maxsize=None)
def read_config_file(filename):
    # Log the information about loading the configuration file.
    logger.info(f"Loading configuration file: {filename}")
    config = ConfigParser()
    config_filepath = os.path.join(os.path.dirname(__file__), filename)
    config.read(config_filepath)
    return config


# Function to get a configuration value using section and key.
@lru_cache(maxsize=None)
def get_config(section, key, decrypt_enabled=True):
    env = os.environ.get('ENV_APP', 'dev')
    # Log the information about getting a configuration value.
    logger.info(f'Getting configuration value for {section}.{key}')
    config_file = CONF_FILES.get(env, 'dev.ini')  # Use get() with a default value
    config = read_config_file(config_file)

    # Use get() with a fallback value
    value = config.get(section, key, fallback=None)

    # If a value is found and it is not base64-encoded, attempt to decrypt it.
    if decrypt_enabled and value and is_base64_encoded(value):
        return decrypt(value)
    return value


# Function to get an encrypted configuration value and decrypt it if needed.
def get_encrypted_config(section, key):
    value = get_config(section, key)
    if value and not is_base64_encoded(value):
        return decrypt(value)
    return value


# Function to load a configuration file.
def load_config_file():
    env = os.environ.get('ENV_APP', 'dev')
    config_file = CONF_FILES.get(env, 'dev.ini')  # Use get() with a default value
    read_config_file(config_file)


# Function to encrypt and store values in the configuration file.
def encrypt_and_store_values(values: list, config_file):
    config = read_config_file(config_file)

    for item in values:
        section = item["section"]
        key = item["key"]
        value = get_config('database', 'POSTGRES_PASSWORD')

        # Encrypt the value if it's not already encrypted.
        encrypted_value = encrypt(value)

        if not encrypted_value:
            continue

        # Store the encrypted value in the configuration file.
        if not config.has_section(section):
            config.add_section(section)
        config.set(section, key, encrypted_value)

    current_dir = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(current_dir, config_file)

    # Save the updated configuration file.
    with open(file_path, 'w') as configfile:
        config.write(configfile)


# encrypt_and_store_values(values_to_encrypt, CONF_FILES.get(os.environ.get('ENV_APP', 'dev'), 'dev.ini'))

if __name__ == '__main__':
    fire.Fire(get_config)