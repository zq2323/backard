from app.core.config.config_reader import get_config as settings
