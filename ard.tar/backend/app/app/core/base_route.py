# CRUD endpoints
from typing import Any, List, Dict
from typing import Type

import pandas as pd
from fastapi import HTTPException, APIRouter, Depends, UploadFile, File, Query, Body
from fastapi.encoders import jsonable_encoder
from pydantic import BaseModel
from sqlalchemy import inspect
from sqlalchemy.orm import Session
from starlette.responses import Response

from app.core.crud import __multi_filter, __paginate, __search
from app.core.session import get_db
from app.modules.metadata import models
import json


class Filter(BaseModel):
    column: str
    filterType: str
    type: str
    filter: str


def crud_router(
        model: Type,
        create_schema: Type,
        update_schema: Type,
        response_schema: Type,
        endpoint: str = None
):
    if endpoint is None:
        endpoint = model.__tablename__

    router = APIRouter()
    print('--------------crud_router--------------------')

    @router.post(f"/{endpoint}", response_model=response_schema)
    async def create(data: create_schema, db: Session = Depends(get_db)):

        # Get the list of columns in the database table
        columns = [column.key for column in inspect(model).columns]

        # Filter out the fields that do not exist in the database table
        valid_data = {field: value for field, value in data.dict().items() if field in columns}
        print('validate before')
        # Create the object using the filtered data
        obj = model(**valid_data)
        print('validate end')

        db.add(obj)
        db.commit()
        db.refresh(obj)
        return jsonable_encoder(obj)

    @router.get(f"/{endpoint}")
    async def read_all(
            page: int = 1,
            limit: int = 10,
            search: str = None,
            filters: str = None,
            db: Session = Depends(get_db)
    ):
        query = db.query(model)
        print('--------------read_all============--------------------')

        # filters = json.loads(filters)

        # Apply search filter if 'q' parameter is provided
        query = await __search(search, query, model)
        print('--------------__search============--------------------')

        # Apply additional filters if provided
        query = await __multi_filter(filters, query, model)
        print('--------------__multi_filter============--------------------')

        # Fetch paginated results and total count
        items, total = await __paginate(query, limit, page)
        print('--------------__paginate============--------------------')
        return {
            'items': [response_schema.from_orm(item).__dict__ for item in items],
            'total': total,
            'page': page
        }

    @router.post(f"/{endpoint}/import")
    async def import_data(file: UploadFile = File(...), db: Session = Depends(get_db)):
        df = pd.read_csv(file.file, dtype=str)

        # Remove empty rows
        df = df.dropna(how='all')

        # Remove empty columns
        df = df.dropna(axis=1, how='all')

        # Replace NaN values with empty strings
        df = df.fillna('')

        # Map DataFrame columns to actual column names using ColumnMapping
        column_mapping = {mapping.custom_name: mapping.actual_name for mapping in
                          db.query(models.ColumnMapping).filter_by(model_name=model.__tablename__).all()}
        df.rename(columns=column_mapping, inplace=True)

        # Convert DataFrame to a list of dictionaries
        records = df.to_dict(orient='records')

        # Insert records into the database
        for record in records:
            obj = model(**record)
            db.add(obj)

        db.commit()

        return {"message": "Data imported successfully"}

    @router.get(f"/{endpoint}/export")
    async def export_data(
            page: int = 1,
            limit: int = 1000,  # set export limit to 1000by default
            search: str = None,
            filters: Any = None,
            exclude_columns: List[str] = None,
            db: Session = Depends(get_db)
    ):
        query = db.query(model)

        # Apply search filter if 'q' parameter is provided
        query = await __search(search, query, model)

        # Apply additional filters if provided
        query = await __multi_filter(filters, query, model)

        # Fetch paginated results and total count
        items, total = await __paginate(query, limit, page)

        # Convert results to a Pandas DataFrame
        df = pd.DataFrame([jsonable_encoder(item) for item in items])

        # Map DataFrame columns to custom column names using ColumnMapping
        column_mapping = {mapping.actual_name: mapping.custom_name for mapping in
                          db.query(models.ColumnMapping).filter_by(model_name=model.__tablename__).all()}
        df.rename(columns=column_mapping, inplace=True)

        # Export DataFrame to CSV format
        return Response(
            content=df.to_csv(index=False),
            media_type="text/csv",
            headers={"Content-Disposition": f"attachment; filename={endpoint}_export.csv"}
        )

    @router.get(f"/{endpoint}/{{item_id}}", response_model=response_schema)
    async def read_item(item_id: int, db: Session = Depends(get_db)):
        obj = db.query(model).filter(model.id == item_id).first()
        if obj is None:
            raise HTTPException(status_code=404, detail=f"{model.__name__} not found")
        return response_schema.from_orm(obj).__dict__

    @router.put(f"/{endpoint}/{{item_id}}", response_model=update_schema)
    async def update_item(item_id: int, data: update_schema, db: Session = Depends(get_db)):
        obj = db.query(model).filter(model.id == item_id).first()
        if obj is None:
            raise HTTPException(status_code=404, detail=f"{model.__name__} not found")

        for field, value in data.dict(exclude_unset=True).items():
            if value is not None and hasattr(obj, field):
                setattr(obj, field, value)

        db.commit()
        db.refresh(obj)
        return response_schema.from_orm(obj).__dict__

    @router.delete(f"/{endpoint}/{{item_id}}", response_model=response_schema)
    async def delete_item(item_id: int, db: Session = Depends(get_db)):
        obj = db.query(model).filter(model.id == item_id).first()
        if obj is None:
            raise HTTPException(status_code=404, detail=f"{model.__name__} not found")
        db.delete(obj)
        db.commit()
        return response_schema.from_orm(obj).__dict__

    return router
