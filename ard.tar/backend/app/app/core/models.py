# Import all the models, so that Base has them before being
# imported by Alembic
from app.core.database.base_model import Base  # noqa
# from app.core.utility.utils import get_model  # noqa
from app.modules.acl.models import *  # noqa
# from app.modules.audit_log.models import *  # noqa
from app.modules.metadata.models import *  # noqa


def get_model(name: str):
    try:
        return eval(name.title().replace("_", ""))
    except NameError:
        pass
