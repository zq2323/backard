import json
from typing import Any, Dict, Generic, List, Optional, Type, TypeVar, Union

from fastapi.encoders import jsonable_encoder
from pydantic import BaseModel
from sqlalchemy.orm import Session
from starlette.requests import Request
from sqlalchemy import or_, cast, String, Numeric

from app.core.database.base_model import Base

ModelType = TypeVar("ModelType", bound=Base)
CreateSchemaType = TypeVar("CreateSchemaType", bound=BaseModel)
UpdateSchemaType = TypeVar("UpdateSchemaType", bound=BaseModel)


class CRUDBase(Generic[ModelType, CreateSchemaType, UpdateSchemaType]):

    def __init__(self, model: Type[ModelType]):
        """
        CRUD object with default methods to Create, Read, Update, Delete (CRUD).

        **Parameters**

        * `model`: A SQLAlchemy model class
        * `schema`: A Pydantic model (schema) class
        """
        self.model = model


async def __paginate(query, limit, page):
    # Calculate skip and limit  values for pagination
    skip = (page - 1) * limit
    # Get items from database
    items = query.offset(skip).limit(limit).all()
    # Count total items
    total = query.count()
    return items, total,


async def __multi_column_search(q, query, model):
    if q:
        search_filters = [getattr(model, column).ilike(f"%{q}%") for column in
                          model.__table__.columns.keys()]
        query = query.filter(or_(*search_filters))
    return query


async def __search(search_query, query, model):
    if search_query:
        filters = []
        for column in model.__table__.columns:
            if isinstance(column.type, String):
                filters.append(column.ilike(f"%{search_query}%"))
            elif hasattr(column.type, "impl") and isinstance(column.type.impl, Numeric):
                filters.append(cast(column, String).ilike(f"%{search_query}%"))
            # else:
            #     filters.append(column == q)
        query = query.filter(or_(*filters))
    return query


async def __multi_order(orders, query, model):
    # Apply multi-column orders
    orders = [] if not orders else json.loads(orders)
    for order in orders:
        column_name = order.get("column")
        order_type = order.get("type")
        if column_name and order_type:
            if order_type == "asc":
                query = query.order_by(getattr(model, column_name).asc())
            elif order_type == "desc":
                query = query.order_by(getattr(model, column_name).desc())
    return query


async def __multi_filter(filters, query, model):
    # Apply multi-column filters

    filters = [] if not filters else json.loads(filters)

    for filter in filters:
        column_name = filter.get("column")
        filter_type = filter.get("type")
        filter_value = filter.get("filter")
        if column_name and filter_type:
            if filter_type == "equals":
                query = query.filter(getattr(model, column_name) == filter_value)
            elif filter_type == "contains":
                query = query.filter(getattr(model, column_name).ilike(f"%{filter_value}%"))
            elif filter_type == "notContains":
                query = query.filter(~getattr(model, column_name).ilike(f"%{filter_value}%"))
            elif filter_type == "startsWith":
                query = query.filter(getattr(model, column_name).ilike(f"{filter_value}%"))
            elif filter_type == "endsWith":
                query = query.filter(getattr(model, column_name).ilike(f"%{filter_value}"))
            elif filter_type == "blank":
                query = query.filter(getattr(model, column_name) == None)
            elif filter_type == "notBlank":
                query = query.filter(getattr(model, column_name) != None)
            elif filter_type == "notEqual":
                query = query.filter(getattr(model, column_name) != filter_value)
            elif filter_type == "greaterThan":
                query = query.filter(getattr(model, column_name) > filter_value)
            elif filter_type == "greaterThanOrEqual":
                query = query.filter(getattr(model, column_name) >= filter_value)
            elif filter_type == "lessThan":
                query = query.filter(getattr(model, column_name) < filter_value)
            elif filter_type == "lessThanOrEqual":
                query = query.filter(getattr(model, column_name) <= filter_value)
            elif filter_type == "inRange":
                min_value, max_value = filter_value.split("-")
                query = query.filter(getattr(model, column_name).between(min_value, max_value))
    return query
