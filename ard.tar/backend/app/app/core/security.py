"""Black-box security shortcuts to generate JWT tokens and password hashing and verifcation."""
import secrets
import time
from typing import Union

import jwt
from fastapi import HTTPException, status
from passlib.context import CryptContext

from app.core.config.config_reader import get_config
from app.modules.acl.schemas import JWTTokenPayload
from app.modules.acl.schemas.security import AccessTokenResponse

# SECRET_KEY = secrets.token_urlsafe(32)
SECRET_KEY = get_config('jwt', 'SECRET_KEY')

JWT_ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_SECS = 60 * 60
REFRESH_TOKEN_EXPIRE_SECS = 60 * 60 * 7
PWD_CONTEXT = CryptContext(
    schemes=["bcrypt"],
    deprecated="auto",
    bcrypt__rounds=get_config('jwt', 'SECURITY_BCRYPT_ROUNDS'),
)


def create_jwt_token(subject: Union[str, int], user: dict, exp_secs: int, refresh: bool):
    """Creates jwt access or refresh token for user.

    Args:
        user: User model
        subject: anything unique to user, id or email etc.
        exp_secs: expire time in seconds
        refresh: if True, this is refresh token
    """

    issued_at = int(time.time())
    expires_at = issued_at + exp_secs

    to_encode: dict[str, Union[str, int, bool]] = {
        "issued_at": issued_at,
        "expires_at": expires_at,
        "sub": subject,
        "refresh": refresh,
        "user": user
    }
    encoded_jwt = jwt.encode(
        to_encode,
        key=SECRET_KEY,
        algorithm=JWT_ALGORITHM,
    )
    return encoded_jwt, expires_at, issued_at


def verify_jwt_token(token: str) -> JWTTokenPayload:
    try:
        payload = jwt.decode(
            token, SECRET_KEY,
            algorithms=[JWT_ALGORITHM]
        )
    except jwt.DecodeError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    # JWT guarantees payload will be unchanged (and thus valid), no errors here
    token_data = JWTTokenPayload(**payload)

    now = int(time.time())
    if now < token_data.issued_at or now > token_data.expires_at:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials, token expired or not yet valid",
            headers={"WWW-Authenticate": "Bearer"},
        )

    return token_data


def generate_access_token_response(subject: Union[str, int], user=dict):
    """Generate tokens and return AccessTokenResponse"""
    access_token, expires_at, issued_at = create_jwt_token(
        subject, user, ACCESS_TOKEN_EXPIRE_SECS, refresh=False
    )
    refresh_token, refresh_expires_at, refresh_issued_at = create_jwt_token(
        subject, user, REFRESH_TOKEN_EXPIRE_SECS, refresh=True
    )
    return AccessTokenResponse(
        token_type="Bearer",
        access_token=access_token,
        expires_at=expires_at,
        issued_at=issued_at,
        refresh_token=refresh_token,
        refresh_token_expires_at=refresh_expires_at,
        refresh_token_issued_at=refresh_issued_at,
    )


def verify_password(plain_password: str, password: str) -> bool:
    """Verifies plain and hashed password matches

    Applies passlib context based on bcrypt algorithm on plain passoword.
    It takes about 0.3s for default 12 rounds of SECURITY_BCRYPT_DEFAULT_ROUNDS.
    """
    return PWD_CONTEXT.verify(plain_password, password)


def get_password_hash(password: str) -> str:
    """Creates hash from password

    Applies passlib context based on bcrypt algorithm on plain passoword.
    It takes about 0.3s for default 12 rounds of SECURITY_BCRYPT_DEFAULT_ROUNDS.
    """
    return PWD_CONTEXT.hash(password)
