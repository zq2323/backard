from sqlalchemy.orm import Session

# import schema
from app.modules.acl import models, schemas  # noqa: F401
from app.utility import utils


class RoleSeeder:

    def __init__(self, db: Session):
        self.db = db

    async def execute(self):
        utils.mark_log("Seeding 'role'")
        await self.create_super_user()
        utils.mark_log("Finished seeding 'role'")

    async def create_super_user(self):
        roles = ['super_admin', 'admin', 'user']

        for role in roles:
            role = self.db.query(models.Role).filter(models.Role.name == role).first()

            if not role:
                db_obj = models.Role(name=role)
                self.db.add(db_obj)
                self.db.commit()
