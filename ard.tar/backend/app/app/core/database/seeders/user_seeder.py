import logging

from faker import Faker
from fastapi.encoders import jsonable_encoder
from sqlalchemy.orm import Session

# import schema
from app.core.config.config_reader import get_config
from app.modules.acl import models, schemas  # noqa: F401
from app.modules.acl.crud import pwd_context
from app.modules.acl.models import User
from app.utility import utils


class UserSeeder:

    def __init__(self, db: Session):
        self.db = db

    async def execute(self):
        utils.mark_log("Seeding 'user'")
        await self.create_super_user()
        # await self.create_random_users()
        utils.mark_log("Finished seeding 'user'")

    async def create_super_user(self):
        user_email = get_config('admin', 'FIRST_SUPERUSER')
        user_password = get_config('admin', 'FIRST_SUPERUSER_PASSWORD')
        user = self.db.query(models.User).filter(models.User.email == user_email).first()
        if not user:
            user_request = schemas.UserRequest(
                first_name='John',
                last_name='Doe',
                email=user_email,
                password=pwd_context.hash(user_password),
                is_superuser=True,
            )

            obj_in_data = jsonable_encoder(user_request)
            db_obj = User(**obj_in_data)  # type: ignore
            self.db.add(db_obj)
            self.db.commit()
            self.db.refresh(db_obj)

    async def create_random_users(self):
        fake = Faker('en_US')
        names = []
        for _ in range(30):
            first_name = fake.unique.first_name()
            last_name = fake.unique.last_name()
            other_names = fake.unique.first_name()
            names.append(first_name)

        logging.info(names)
