from sqlalchemy import MetaData
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import scoped_session

from app.core.config.config_reader import get_config
from app.core.session import SessionLocal

Base = declarative_base(metadata=MetaData(schema=get_config('database', 'POSTGRES_SCHEMA')))
# Base.query = scoped_session(SessionLocal).query_property()

Base.schema = 'metadata_mgr'
