from sqlalchemy.orm import Session

from app.core.database import seeders as seeder
from app.core.models import Base
from typing import Generator

from pydantic import PostgresDsn
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.core.config.config_reader import get_config

def get_uri():
    print('------------------------------------test-----------------')
    return PostgresDsn.build(
        scheme="postgresql",
        user='tel',
        password='let',
        host='db',
        path=f"/fz_metadata",
    )

# synchronous connection
engine = create_engine(get_uri(), pool_pre_ping=True)
with engine.connect() as conn:
    conn.execute('CREATE SCHEMA IF NOT EXISTS metadata_mgr')
async def init_db(db: Session) -> None:
    # Tables should be created with Alembic migrations
    # But if you don't want to use migrations, create
    # the tables un-commenting the next line
    Base.metadata.create_all(bind=engine)
    # await seeder.RoleSeeder(db).execute()
    # await seeder.UserSeeder(db).execute()
    pass
