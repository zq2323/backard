from typing import Generator

from pydantic import PostgresDsn
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.core.config.config_reader import get_config

def get_uri():
    print('------------------------------------test-----------------')
    return PostgresDsn.build(
        scheme="postgresql",
        user='tel',
        password='let',
        host='db',
        path=f"/fz_metadata",
    )
    # return PostgresDsn.build(
    #     scheme="postgresql",
    #     user=get_config('database', 'POSTGRES_USER'),
    #     password=get_config('database', 'POSTGRES_PASSWORD'),
    #     host=get_config('database', 'POSTGRES_SERVER'),
    #     path=f"/{get_config('database', 'POSTGRES_DB') or ''}",
    # )


# synchronous connection
engine = create_engine(get_uri(), pool_pre_ping=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def get_db() -> Generator:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
