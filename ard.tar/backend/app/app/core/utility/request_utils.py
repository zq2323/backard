import logging
import os

import requests

from app.core.config.config_reader import get_config
from app.core.utility.utils import decrypt, encrypt

logger = logging.getLogger(__name__)


# def configure_requests_ca_bundle():
#     os.environ['REQUESTS_CA_BUNDLE'] = './company_root_ca.crt'


def get_keycloak_access_token():
    keycloak_url = f"{get_config('keycloak', 'AUTH_URI')}/"
    keycloak_realm = get_config('keycloak', 'REALM')
    keycloak_client_id = get_config('keycloak', 'CLIENT_ID')
    keycloak_client_secret = get_config('keycloak', 'CLIENT_SECRET', decrypt_enabled=False)

    logger.info('\nStep 1: Get an access token for the client')

    token_url = f"{keycloak_url}realms/{keycloak_realm}/protocol/openid-connect/token"
    payload = {
        'client_id': keycloak_client_id,
        'client_secret': keycloak_client_secret,
        'grant_type': 'client_credentials',
        'scope': 'openid'
    }
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}

    logger.info(f"headers={headers}\npayload={payload}\nurl={token_url}\n")

    try:
        response = requests.post(token_url, data=payload, headers=headers, verify=False)

        if response.status_code == 200:
            admin_token = response.json().get('access_token')
            return admin_token
        else:
            logger.error(f"Error obtaining access token: {response.status_code} - {response.text}")

    except requests.exceptions.RequestException as req_exception:
        # Handle general request exceptions
        logger.error(f"Request exception: {req_exception}")
    except Exception as general_exception:
        # Handle any other unexpected exceptions
        logger.error(f"An unexpected error occurred: {general_exception}")


def request_e_wise_api_token(username, admin_token, force_renewal=False):
    e_wise_uri = get_config('ewise', 'API_URL')
    e_wise_version = get_config('ewise', 'API_VERSION')
    e_wise_username = username

    # eWise variables
    e_wise_url = "{api_url}/{api_version}/token".format(
        api_url=e_wise_uri,
        api_version=e_wise_version
    )

    logger.info('Step 2: Request eWise API token for the given username')
    e_wise_url = e_wise_url

    params = {
        'username': e_wise_username,
        'force_renewal': force_renewal
    }

    headers = {
        'Authorization': f'Bearer {admin_token}'
    }

    logger.info(f"headers={headers}")
    logger.info(f"payload={params}")
    logger.info(f"url={e_wise_url}\n")

    response = requests.get(e_wise_url, params=params, headers=headers, verify=False)

    if response.status_code == 200:
        user_token = response.json()
        logger.info(f"user_token={user_token}")
        return user_token
    else:
        logger.error(f"Error obtaining user token: {response.status_code} - {response.text}")


def upload_file_to_ewise(
        url,
        headers,
        params,
        file_name,
        file_data,
        current_user,
        db,
        verify=False
):
    """
    Upload files to eWise API.

    Parameters:
    - url (str): The API endpoint URL.
    - headers (dict): Headers to be included in the request.
    - params (dict): Additional parameters to include in the API request.
    - file_name (str): The name of the file to be uploaded.
    - file_data (bytes): The content of the file to be uploaded as bytes.
    - current_user: Current user object.
    - db: Database session.
    - verify (bool): SSL verification flag.

    Returns:
    - dict: Result of the upload operation.
    """
    status = False
    status_code = None
    message = ""

    try:
        # Initial request
        response = requests.post(
            url,
            headers=headers,
            files={'file': (file_name, file_data)},
            params=params,
            verify=verify
        )

        message = response.text
        status_code = response.status_code
        status = (status_code == 200)

        if status_code == 201:
            # If the status code is 201, update the eWise token and retry the request
            e_wise_token = update_e_wise_token(current_user, db)

            # Retry the request with the updated token
            headers['Authorization'] = f"Bearer {e_wise_token}"
            response = requests.post(
                url,
                headers=headers,
                files={'file': (file_name, file_data)},
                params=params,
                verify=verify
            )
            status_code = response.status_code
            status = (status_code == 200)

    except requests.exceptions.ConnectionError as e:
        # Handle ConnectionError cases
        message = handle_connection_error(e)

    return {
        'status': status,
        'status_code': status_code,
        'message': message,
    }


def update_e_wise_token(current_user, db):
    # Update eWise token for the current user
    e_wise = request_e_wise_api_token(
        admin_token=get_keycloak_access_token(),
        username=current_user.username
    )

    current_user.e_wise_token = encrypt(e_wise.value)
    current_user.e_wise_token_expiry = e_wise.expiration_date
    db.commit()

    return decrypt(current_user.e_wise_token)


def handle_connection_error(e):
    # Handle specific ConnectionError cases
    if "Max retries exceeded" in str(e):
        return "Error: Max retries exceeded. Check your internet connection."
    elif "Name or service not known" in str(e):
        return "Error: Failed to resolve 'ewise-api.com'. Please check the domain name."
    else:
        return f"ConnectionError: {e}"


def submit_ewise_batch_job(
        url,
        headers,
        params,
        verify=False
):
    """
        Submit Batch Job Via eWise API.

        Parameters:
        - url (str): The API endpoint URL.
        - headers (dict): Headers to be included in the request.
        - params (dict): Additional parameters to include in the API request.
        - verify (bool): SSL verification flag.

        Returns:
        - dict: Result of the upload operation.
        """
    status = False
    status_code = None
    try:
        response = requests.post(
            url,
            headers=headers,
            params=params,
            verify=verify  # Set verify to False to skip SSL verification (Use with caution)
        )

        message = response.text
        status_code = response.status_code
        status = (status_code == 200)
    except requests.exceptions.ConnectionError as e:
        if "Max retries exceeded" in str(e):
            # Handle the Max retries exceeded error
            message = "Error: Max retries exceeded. Check your internet connection."
        elif "Name or service not known" in str(e):
            # Handle the DNS resolution failure
            message = "Error: Failed to resolve 'ewise-api.com'. Please check the domain name."
        else:
            # Handle other ConnectionError cases
            message = f"ConnectionError: {e}"

    return {
        'status': status,
        'status_code': status_code,
        'message': message,
    }
