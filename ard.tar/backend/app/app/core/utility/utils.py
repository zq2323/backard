import base64
import csv
import logging
import mimetypes
import os
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from urllib.parse import urlparse

import chardet
import pandas as pd
from cryptography.fernet import Fernet

logger = logging.getLogger(__name__)

encryption_key = os.environ.get('ENCRYPTION_KEY')

cipher_suite = Fernet(encryption_key)


def __get(needle, haystack, default=""):
    return haystack[needle] if needle in haystack else ""


# def save_media_file(db, url: str) -> Any:
#     file_path = save_file(url)
#
#     # get mime_type
#     mime_type = get_mime_type(file_path)
#
#     # save media
#     data = {
#         "name": "",
#         "path": save_file(url),
#         "size": Path(file_path).stat().st_size,
#         "ext": Path(file_path).suffix,
#         "mime_type": mime_type
#     }
#     db.add(models.Media(**data))
#     db.commit()
#     return data


def save_file(url: str, file_name: str = None) -> str:
    # set download path
    path = make_path("assets/downloads/file/")

    # create file path locally if it doesn't already exists
    if not file_name:
        file_name = str(Path(urllib.parse.urlparse(url).path).name)

    # set full file path (In some cases you may need to add a time stamp to the file name to make it unique)
    file_name = path + file_name

    try:
        file = urllib.request.urlretrieve(url, file_name)
        logging.info(file)
    except urllib.error.URLError as e:
        logging.debug(e)
    except Exception as e:
        logging.debug(e)

    return file_name


def make_path(path: str) -> str:
    Path(path).mkdir(parents=True, exist_ok=True)
    return path


def get_mime_type(file_path: str) -> str:
    mime_types = mimetypes.guess_type(file_path)
    mime_type = mime_types[0] if mime_types else None
    return mime_type


def response(message: str = "", status: bool = False, data: dict = None) -> object:
    return {
        'status': status,
        'message': message,
        'data': data
    }


def remove_quotes(s):
    """
    Check if a string is wrapped with quotes and remove them.

    Args:
        s (str): Input string.

    Returns:
        str: The input string with quotes removed, if applicable.
    """
    if len(s) >= 2 and s[0] == s[-1] and s[0] in ('"', "'"):
        return s[1:-1]
    else:
        return s


def snake_to_camel_case(snake_case_string):
    words = snake_case_string.split('_')
    return words[0] + ''.join(word.title() for word in words[1:])


def get_permissions(ref_list_name, repo_list):
    permissions = []
    for repo in repo_list:
        if repo['name'] == ref_list_name:
            permissions.append({
                'read': repo['isOwner'],
                'write': repo['isWriteAccess'],
            })

    return permissions


# Function to encrypt a text value.
def encrypt(text):
    try:
        if text and not is_base64_encoded(text):
            encrypted_bytes = cipher_suite.encrypt(text.encode())
            encrypted_str = base64.urlsafe_b64encode(encrypted_bytes).decode()
            return encrypted_str
    except Exception as e:
        # Log the error with a stack trace if encryption fails.
        logger.error("Encryption error", exc_info=True)
    return text


# Function to decrypt an encrypted text.
def decrypt(encrypted_text):
    try:
        if is_base64_encoded(encrypted_text):
            encrypted_bytes = base64.urlsafe_b64decode(encrypted_text)
            decrypted_text = cipher_suite.decrypt(encrypted_bytes).decode()
            return decrypted_text
    except Exception as e:
        # Log the error with a stack trace if decryption fails.
        # logger.error("Decryption error", exc_info=True)
        pass
    return encrypted_text


def is_base64_encoded(s):
    return not is_valid_url(s) and is_valid_base64(s)


def is_valid_base64(s):
    try:
        base64.b64decode(s)
        return True
    except Exception:
        return False


def is_valid_url(url):
    try:
        result = urlparse(url)
        return all([result.scheme, result.netloc])
    except ValueError:
        return False
    except ValueError:
        return False


def read_csv_with_encoding(file_path, delimiters=None, encodings=None):
    if encodings is None:
        encodings = ['utf-16', 'utf-8', 'unicode_escape', 'latin1', 'iso-8859-1', 'cp1252']
    if delimiters is None:
        delimiters = [' ', ',', '\t']

    return pd.read_csv(file_path, encoding='utf-16-le', delimiter='\t')
    # for encoding in encodings:

    for delimiter in delimiters:
        try:
            df = pd.read_csv(file_path, encoding=encoding, delimiter=delimiter)
            if isinstance(df, pd.DataFrame):
                print('good!!!')
                return df  # Return the DataFrame if successful
        except pd.errors.ParserError as e:
            print(f"ParserError: {e}")
        except pd.errors.EmptyDataError as e:
            print(f"EmptyDataError: {e}")
        except Exception as e:
            print(f"Failed to read CSV with encoding {encoding} and delimiter {delimiter}: {e}")

    # If none of the encodings worked, you may want to handle this case accordingly
    print("Failed to read CSV with any encoding and delimiter.")
    return None


def read_file(file):
    try:
        if file.filename.endswith('.csv'):
            df = read_csv_with_encoding(file.file)
        else:
            df = pd.read_excel(file.file)
        return df
    except Exception as e:
        return response(f"Error processing file: {e}")


def detect_delimiter(file, encoding):
    sample = file.read().decode(encoding)  # Decode the bytes to a string
    file.seek(0)  # Reset file position to the beginning
    sniffer = csv.Sniffer()
    delimiter = sniffer.sniff(sample).delimiter
    return delimiter


def detect_encoding(file):
    result = chardet.detect(file.read())
    file.seek(0)
    return result['encoding']


def read_csv_with_detection(file, delimiter=None):
    encoding = detect_encoding(file)

    if not delimiter:
        delimiter = detect_delimiter(file, encoding)
        print(f"Delimiter: {delimiter}")
    else:
        delimiter = convert_delimiter(delimiter)

    # Read the CSV file using the determined encoding and delimiter
    df = pd.read_csv(file, encoding=encoding, delimiter=delimiter)
    return df


def convert_delimiter(form_value):
    delimiter_mapping = {
        'comma': ',',
        'space': ' ',
        'tab': '\t',
        'semicolon': ';',
        'pipe': '|'
    }

    return delimiter_mapping.get(form_value, ',')


def split_and_trim(text):
    # Split the text using forward slash and strip (remove leading/trailing spaces) each part
    parts = [part.strip() for part in text.split('/')]

    return parts


def determine_e_wise_access(repositories):
    access_list = []

    for repository in repositories:
        access = {
            'name': repository['name'],
            'read': repository['isOwner'] or repository['isWriteAccess'],
            'write': repository['isWriteAccess'],
            'delete': repository['isOwner'] and repository['isWriteAccess'],
        }
        access_list.append(access)

    return access_list


def get_model(name: str):
    try:
        return eval(name.title().replace("_", ""))
    except NameError:
        pass
