from fastapi import Query


def operation(q: str = Query(default=None, description="Search term"),
              filters: list = Query([], alias="filter", description="Multi-dimensional array of column, operation & value"),
              orders: list = Query([], alias="order", description="Multi-dimensional array of columns & sort order")):
    return {
        'q': q,
        'filters': filters,
        'orders': orders,
    }


def paginate(
        page: int = Query(default=1, description="current page"),
        limit: int = Query(default=10, description="Items per page")
) -> dict:
    return {
        'page': page,
        'limit': limit,
    }
