import datetime

from sqlalchemy import Column, DateTime, Boolean, Integer, ForeignKey
from sqlalchemy.ext.declarative import declared_attr
from sqlalchemy.orm import declarative_mixin, relationship  # noqa
from sqlalchemy.dialects.postgresql import UUID


# @declarative_mixin
class AuditMixin(object):
    """
        AuditMixin
        Mixin for models, adds 4 columns to stamp,
        time and user on creation and modification
        will create the following columns:

        :created at:
        :changed at:
        :deleted at:
        :created by:
        :changed by:
    """

    @declared_attr
    def created_at(cls):
        return Column(DateTime, default=datetime.datetime.now, nullable=False)

    @declared_attr
    def updated_at(cls):
        return Column(
            DateTime,
            default=datetime.datetime.now,
            onupdate=datetime.datetime.now,
            nullable=False,
        )

    @declared_attr
    def deleted_at(cls):
        return Column(DateTime, nullable=True)

    @declared_attr
    def created_by_id(cls):
        return Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=True)

    @declared_attr
    def updated_by_id(cls):
        return Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=True)

    @declared_attr
    def deleted_by_id(cls):
        return Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=True)

    @declared_attr
    def created_by(cls):
        return relationship("User", foreign_keys=[cls.created_by_id], uselist=False)

    @declared_attr
    def updated_by(cls):
        return relationship("User", foreign_keys=[cls.updated_by_id], uselist=False)

    @declared_attr
    def deleted_by(cls):
        return relationship("User", foreign_keys=[cls.deleted_by_id], uselist=False)
