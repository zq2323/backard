import time

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware

# import routers
from app.core.config.config_reader import get_config
from app.modules.acl.api.v1 import api_router as acl_router_v1
from app.modules.metadata.api.v1 import api_router as metadata_router_v1

API_V1_STR = get_config('app', 'API_V1_STR')

app = FastAPI(
    title=get_config('app', 'PROJECT_NAME'),
    description=get_config('app', 'PROJECT_DESCRIPTION'),
    openapi_url=f"{get_config('app', 'API_V1_STR')}/openapi.json",
    docs_url='/api/docs'
)

# models.Base.metadata.create_all(bind=engine)

# Set all CORS enabled origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    return response


# register routers
print('------------test1-------------------')
app.include_router(acl_router_v1, prefix=API_V1_STR)
app.include_router(metadata_router_v1, prefix=API_V1_STR)
