from sqlalchemy import Column, Integer, String, DateTime, JSON, inspect
from sqlalchemy import event
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Session
from sqlalchemy.sql import func

from app.core.database.base_model import Base
from app.modules.reflist.models import RefList, RefListSection, RefListOutput


class AuditLog(Base):
    __tablename__ = 'audit_log'

    id = Column(Integer, primary_key=True, autoincrement=True)
    table_name = Column(String, nullable=False)
    action = Column(String, nullable=False)
    record_id = Column(Integer, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    user_id = Column(UUID(as_uuid=True), nullable=True)  # Capture the user who made the change
    old_data = Column(JSON)
    new_data = Column(JSON)


# Define a function to filter data based on allowed columns
def filter_data(data, allowed_columns):
    return {key: value for key, value in data.items() if key in allowed_columns}


# @event.listens_for(RefList, 'before_insert')
# @event.listens_for(RefListOutput, 'before_insert')
# @event.listens_for(RefListSection, 'before_insert')
def capture_insert_audit_log(mapper, connection, target):
    action = 'insert'
    table_name = target.__tablename__
    record_id = target.id
    user_id = 1  # Replace with your user authentication logic

    new_data = {c.name: getattr(target, c.name) for c in target.__table__.columns}

    user_id = new_data.get('created_by_id')

    # Obtain a SQLAlchemy session from the connection
    session = Session(bind=connection)

    # Create and add the audit log entry
    audit_log = create_audit_log(action, table_name, record_id, user_id, new_data=new_data)
    session.add(audit_log)

    # Commit the changes to the database
    session.commit()
    session.close()


# @event.listens_for(RefList, 'before_update')
# @event.listens_for(RefListOutput, 'before_update')
# @event.listens_for(RefListSection, 'before_update')
def capture_update_audit_log(mapper, connection, target):
    action = 'update'
    table_name = target.__tablename__
    record_id = target.id
    user_id = 1  # Replace with your user authentication logic

    # Get the state of the object before the update
    state = inspect(target).attrs
    allowed_columns = target.__table__.columns

    old_data = {key: state[key].history.deleted if state[key].history.has_changes() else state[key].value for key in
                state.keys()}
    new_data = {key: state[key].value for key in state.keys()}

    user_id = old_data.get('updated_by_id', 0)

    # Filter the data dictionaries to keep only allowed columns
    old_data = filter_data(old_data, allowed_columns)
    new_data = filter_data(new_data, allowed_columns)

    # Obtain a SQLAlchemy session from the connection
    session = Session(bind=connection)

    # Create and add the audit log entry to the session
    audit_log = create_audit_log(action, table_name, record_id, user_id, old_data=old_data, new_data=new_data)
    session.add(audit_log)

    # Commit the changes to the database
    session.commit()
    session.close()


# @event.listens_for(RefList, 'before_delete')
# @event.listens_for(RefListOutput, 'before_delete')
# @event.listens_for(RefListSection, 'before_delete')
def capture_delete_audit_log(mapper, connection, target):
    action = 'delete'
    table_name = target.__tablename__
    record_id = target.id
    user_id = 1  # Replace with your user authentication logic

    old_data = {c.name: getattr(target, c.name) for c in target.__table__.columns}

    # Obtain a SQLAlchemy session from the connection
    session = Session(bind=connection)

    # Create and add the audit log entry
    audit_log = create_audit_log(action, table_name, record_id, user_id, old_data=old_data)
    session.add(audit_log)

    # Commit the changes to the database
    session.commit()
    session.close()


def create_audit_log(action, table_name, record_id, user_id, old_data=None, new_data=None):
    # Create an audit log entry
    audit_log = AuditLog(
        table_name=table_name,
        action=action,
        record_id=record_id,
        user_id=user_id,
        old_data=str(old_data),
        new_data=str(new_data)
    )

    return audit_log
