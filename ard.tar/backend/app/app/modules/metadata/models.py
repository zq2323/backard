from fastapi import Depends
from sqlalchemy import String, String, Column, ForeignKey, Boolean, UniqueConstraint, Float, DECIMAL, Integer

from app.core.database.base_model import Base


class PlannedOutputs(Base):
    __tablename__ = 'planned_outputs'

    id = Column(Integer, primary_key=True, index=True)
    section = Column(String)
    # variable_status = Column(Enum('Input', 'Output', 'Intermediate'))
    tlf_name = Column(String)
    table_desc = Column(String)
    table_loc = Column(String)
    app_order = Column(String)
    analysis_status = Column(String)
    categorization = Column(String)
    orientation = Column(String)
    subject = Column(String)
    sort_keys = Column(String)
    arm_prog = Column(String)
    ta = Column(String)


class PlannedAnalyses(Base):
    __tablename__ = 'planned_analyses'

    id = Column(Integer, primary_key=True, index=True)
    tlf_name = Column(String, comment="TLF name")
    analysis_status = Column(String, comment="Analysis Status")
    anl_name = Column(String, comment="Name")
    analyses_id = Column(String, comment="Analysis ID")
    analysisset_id = Column(String, comment="AnalysisSet ID")
    display_order = Column(String, comment="Output display order")
    


class AnalysisGroupings(Base):
    __tablename__ = 'analysis_groupings'

    id = Column(Integer, primary_key=True, index=True)
    grouping_type = Column(String, comment="Grouping Type")
    Anl_groupingid = Column(String, comment="Analysis Grouping ID")
    label = Column(String, comment="Label")
    grp_var = Column(String, comment="Grouping Variable")
    data_driven = Column(String, comment="Data Driven")
    analysis_status = Column(String, comment="Analysis Status")
    group_label = Column(String, comment="Group label")
    group_level = Column(String, comment="group_level")
    group_logical = Column(String, comment="group_logical")
    group__dataset = Column(String, comment="group__dataset")
    group_variable = Column(String, comment="group_variable")
    group_comparator = Column(String, comment="group_comparator")
    group_value = Column(String, comment="group_value")


class AnalysisSets(Base):
    __tablename__ = 'analysis_sets'

    id = Column(Integer, primary_key=True, index=True)
    analysisset_id = Column(String, comment="AnalysisSets ID")
    label = Column(String, comment="Label")
    level = Column(String, comment="Level")
    order = Column(String, comment="Order")
    logical_operator = Column(String, comment="Logical Operator")
    condition_dataset = Column(String, comment="Condition dataset")
    condition_variable = Column(String, comment="Condition variable")
    condition_comparator = Column(String, comment="Condition comparator")
    condition_value = Column(String, comment="Condition value")
    count_id = Column(String, comment="Count ID")


class DataSubsets(Base):
    __tablename__ = 'data_subsets'

    id = Column(Integer, primary_key=True, index=True)
    tlf_name = Column(String, comment="TLF Name")
    datasubset_id = Column(String, comment="DataSubsets ID")
    label = Column(String, comment="Label")
    level = Column(String, comment="Level")
    order = Column(String, comment="Order")
    logical_operator = Column(String, comment="Logical Operator")
    condition_dataset = Column(String, comment="Condition dataset")
    condition_variable = Column(String, comment="Condition variable")
    condition_comparator = Column(String, comment="Condition comparator")
    condition_value = Column(String, comment="Condition value")
    count_id = Column(String, comment="Count ID")


class AnalysisMethods(Base):
    __tablename__ = 'analysis_methods'

    id = Column(Integer, primary_key=True, index=True)
    method_id = Column(String, comment="Method ID")
    description = Column(String, comment="Description")
    stat_id = Column(String, comment="Statistics ID")
    stat_name = Column(String, comment="Statistics Name")
    link = Column(String, comment="Link")
    stat_label = Column(String, comment="Statistics Label")


class Analyses(Base):
    __tablename__ = 'analyses'

    id = Column(Integer, primary_key=True, index=True)
    analyses_id = Column(String, comment="Analyses ID")
    name = Column(String, comment="Name")
    categoryids = Column(String, comment="Category ID")
    reason = Column(String, comment="Reason")
    purpose = Column(String, comment="Purpose")
    analysisset_id = Column(String, comment="AnalysisSet ID")
    groupingid_1 = Column(String, comment="Grouping ID 1")
    results_bygrp1 = Column(String, comment="Results By Group 1")
    groupingid_2 = Column(String, comment="Grouping ID 2")
    results_bygrp2 = Column(String, comment="Results By Group 2")
    groupingid_3 = Column(String, comment="Grouping ID 3")
    results_bygrp3 = Column(String, comment="Results By Group 3")
    groupingid_4 = Column(String, comment="Grouping ID 4")
    results_bygrp4 = Column(String, comment="Results By Group 4")
    datasubset_id = Column(String, comment="Datasubset ID")
    dataset = Column(String, comment="Analysis Dataset")
    variable = Column(String, comment="Analysis Variable")
    method_id = Column(String, comment="Analysis Method")
    refer_anl1 = Column(String, comment="Referenced Analysis 1")
    refer_anl2 = Column(String, comment="Referenced Analysis 2")


class ColumnMapping(Base):
    __tablename__ = 'column_mapping'

    id = Column(Integer, primary_key=True)
    model_name = Column(String, nullable=False)
    actual_name = Column(String, nullable=False)
    custom_name = Column(String, nullable=False)
