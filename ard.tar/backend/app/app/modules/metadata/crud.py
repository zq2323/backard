from fastapi import HTTPException, Depends
from typing import List, Optional, Type, TypeVar

from sqlalchemy.orm import DeclarativeMeta, class_mapper, Session

from app.core.session import get_db
from app.core.database.base_model import Base
from app.modules.metadata.models import ColumnMapping

ModelType = TypeVar("ModelType", bound=Base)


class CRUDBase:
    def __init__(self, model: Type[ModelType]):
        self.model = model

    def get_all(self, skip: int = 0, limit: int = 100) -> List[Optional[ModelType]]:
        return self.model.query().offset(skip).limit(limit).all()

    def get(self, id: int) -> Optional[ModelType]:
        return self.model.query().get(id)

    def create(self, obj_in: ModelType) -> ModelType:
        obj_in_db = self.model(**obj_in.dict())
        obj_in_db.save()
        return obj_in_db

    def update(self, id: int, obj_in: ModelType) -> Optional[ModelType]:
        obj = self.get(id)
        if not obj:
            return None
        for key, value in obj_in.dict().items():
            setattr(obj, key, value)
        obj.save()
        return obj

    def delete(self, id: int) -> Optional[ModelType]:
        obj = self.get(id)
        if not obj:
            return None
        obj.delete()
        return obj


async def synchronize_column_mapping(
        db: Session = Depends(get_db), model_class=None):
    # Get the existing column mappings for the model
    existing_mappings = {mapping.actual_name: mapping for mapping in
                         db.query(ColumnMapping).filter_by(model_name=model_class.__tablename__).all()}

    # Get the columns of the model
    mapper = class_mapper(model_class)
    columns = [col.key for col in mapper.columns]

    # Add new columns to ColumnMapping
    for column in columns:
        if column not in existing_mappings:
            new_mapping = ColumnMapping(
                model_name=model_class.__tablename__,
                custom_name=column,
                actual_name=column
            )
            db.add(new_mapping)
            db.commit()

    # Remove columns that are no longer present in the model
    for actual_name, mapping_obj in existing_mappings.items():
        if actual_name not in columns:
            db.delete(mapping_obj)
            db.commit()
