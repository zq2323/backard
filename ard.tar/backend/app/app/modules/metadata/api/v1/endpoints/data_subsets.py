# CRUD endpoints
from app.modules.metadata import models
from app.modules.metadata import schemas
from app.core.base_route import crud_router

router = crud_router(
    models.DataSubsets,
    schemas.DataSubsetsCreate,
    schemas.DataSubsetsUpdate,
    schemas.DataSubsets,
)