# CRUD endpoints
from app.modules.metadata import models
from app.modules.metadata import schemas

# Create a router for the PlannedOutputs model
from app.core.base_route import crud_router

router = crud_router(
    models.PlannedOutputs,
    schemas.PlannedOutputsCreate,
    schemas.PlannedOutputsUpdate,
    schemas.PlannedOutputs,
)