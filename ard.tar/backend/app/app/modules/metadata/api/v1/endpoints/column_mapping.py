# CRUD endpoints
from typing import List, Any

from fastapi.encoders import jsonable_encoder

from app.core.crud import __paginate, __search, __multi_filter
from app.core.session import get_db
from fastapi import HTTPException, APIRouter, Depends
from sqlalchemy.orm import Session, joinedload
from app.modules.metadata import models
from app.modules.metadata import schemas

# from app.modules.metadata.api.v1.endpoints.base_route import crud_router
# 
# # Create a router for the ColumnMapping model
# router = crud_router(
#     models.ColumnMapping,
#     schemas.ArdaeCreate,
#     schemas.ArdaeUpdate,
#     schemas.ColumnMapping,
# )
from app.modules.metadata.crud import synchronize_column_mapping

model_dict = {
    'planned_outputs': models.PlannedOutputs,
    'planned_analyses': models.PlannedAnalyses,
    'analysis_groupings': models.AnalysisGroupings,
    'analysis_sets': models.AnalysisSets,
    'data_subsets': models.DataSubsets,
    'analysis_methods': models.AnalysisMethods,
    'analyses': models.Analyses
}

router = APIRouter()


# router = APIRouter()
@router.post("/column_mapping", response_model=schemas.ColumnMapping)
async def create(column_mapping: schemas.ColumnMappingCreate, db: Session = Depends(get_db)):
    column_mapping_obj = models.ColumnMapping(**column_mapping.dict())
    db.add(column_mapping_obj)
    db.commit()
    db.refresh(column_mapping_obj)
    return jsonable_encoder(column_mapping_obj)


@router.get("/column_mapping", )
async def read_all(
        page: int = 1,
        limit: int = 10,
        search: str = None,
        filters: Any = None,
        model_name: str = None,
        db: Session = Depends(get_db)
):
    await synchronize_column_mapping(db, model_dict.get(model_name))
    query = db.query(models.ColumnMapping).filter_by(**{'model_name': model_name})

    # Apply search filter if 'q' parameter is provided
    query = await __search(search, query, models.ColumnMapping)

    # Apply additional filters if provided
    query = await __multi_filter(filters, query, models.ColumnMapping)

    # Fetch paginated results and total count
    items, total = await __paginate(query, limit, page)
    return {
        'items': [jsonable_encoder(item) for item in items],
        'total': total,
        'page': page
    }


@router.get("/column_mapping/{column_mapping_id}", response_model=schemas.ColumnMapping)
async def read_column_mapping(column_mapping_id: int, db: Session = Depends(get_db)):
    column_mapping = db.query(models.ColumnMapping).filter(models.ColumnMapping.id == column_mapping_id).first()
    if column_mapping is None:
        raise HTTPException(status_code=404, detail="ColumnMapping not found")
    return jsonable_encoder(column_mapping)


@router.put("/column_mapping/{column_mapping_id}", response_model=schemas.ColumnMappingUpdate)
async def update_column_mapping(column_mapping_id: int, column_mapping: schemas.ColumnMappingUpdate, db: Session = Depends(get_db)):
    column_mapping_obj = db.query(models.ColumnMapping).filter(models.ColumnMapping.id == column_mapping_id).first()
    if column_mapping_obj is None:
        raise HTTPException(status_code=404, detail="ColumnMapping not found")

    for field, value in column_mapping.dict(exclude_unset=True).items():
        if value is not None:
            setattr(column_mapping_obj, field, value)  # Update fields with new values

    db.commit()
    db.refresh(column_mapping_obj)
    return jsonable_encoder(column_mapping_obj)


@router.delete("/column_mapping/{column_mapping_id}", response_model=schemas.ColumnMapping)
async def delete_column_mapping(column_mapping_id: int, db: Session = Depends(get_db)):
    column_mapping_obj = db.query(models.ColumnMapping).filter(models.ColumnMapping.id == column_mapping_id).first()
    if column_mapping_obj is None:
        raise HTTPException(status_code=404, detail="ColumnMapping not found")
    db.delete(column_mapping_obj)
    db.commit()
    return jsonable_encoder(column_mapping_obj)
