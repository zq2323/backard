from fastapi import APIRouter

from .endpoints import planned_outputs
from .endpoints import planned_analyses
from .endpoints import analysis_groupings
from .endpoints import analysis_sets
from .endpoints import data_subsets
from .endpoints import analysis_methods
from .endpoints import analyses
from .endpoints import column_mapping

api_router = APIRouter()
api_router.include_router(planned_outputs.router, tags=["planned_outputs"])
api_router.include_router(planned_analyses.router, tags=["planned_analyses"])
api_router.include_router(analysis_groupings.router, tags=["analysis_groupings"])
api_router.include_router(analysis_sets.router, tags=["analysis_sets"])
api_router.include_router(data_subsets.router, tags=["data_subsets"])
api_router.include_router(analysis_methods.router, tags=["analysis_methods"])
api_router.include_router(analyses.router, tags=["analyses"])
api_router.include_router(column_mapping.router, tags=["column_mapping"])

# api_router.include_router(ardae.router, tags=["ardae"])
# api_router.include_router(analysis_metadata.router, tags=["analysis_metadata"])
# api_router.include_router(big_n.router, tags=["big_n"])
# api_router.include_router(dataset_level.router, tags=["dataset_level"])
# api_router.include_router(details_subpop_test.router, tags=["details_subpop_test"])
# api_router.include_router(metadata.router, tags=["metadata"])
# api_router.include_router(report_columns.router, tags=["report_columns"])
# api_router.include_router(statistics.router, tags=["statistics"])
# api_router.include_router(tlf_format_metadata.router, tags=["tlf_format_metadata"])
# api_router.include_router(column_mapping.router, tags=["column_mapping"])