# CRUD endpoints
from app.modules.metadata import models
from app.modules.metadata import schemas
from app.core.base_route import crud_router

router = crud_router(
    models.AnalysisGroupings,
    schemas.AnalysisGroupingsCreate,
    schemas.AnalysisGroupingsUpdate,
    schemas.AnalysisGroupings,
)