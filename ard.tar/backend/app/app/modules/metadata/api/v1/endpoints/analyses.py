# CRUD endpoints
from app.modules.metadata import models, schemas
from app.core.base_route import crud_router

router = crud_router(
    models.Analyses,
    schemas.AnalysesCreate,
    schemas.AnalysesUpdate,
    schemas.Analyses,
)