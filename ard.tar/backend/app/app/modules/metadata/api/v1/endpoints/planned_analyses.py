# CRUD endpoints
from app.modules.metadata import models
from app.modules.metadata import schemas
from app.core.base_route import crud_router

# Create a router for the PlannedAnalyses model
router = crud_router(
    models.PlannedAnalyses,
    schemas.PlannedAnalysesCreate,
    schemas.PlannedAnalysesUpdate,
    schemas.PlannedAnalyses,
)