from pydantic import BaseModel, Field
from typing import Optional


class PlannedOutputsBase(BaseModel):
    section: Optional[str] = Field(None, description="Section")
    tlf_name: Optional[str] = Field(None, description="TLF Name")
    table_desc: Optional[str] = Field(None, description="Table Descriptions")
    table_loc: Optional[str] = Field(None, description="Table Location")
    app_order: Optional[str] = Field(None, description="Appendix order")
    analysis_status: Optional[str] = Field(None, description="Analysis Status")
    categorization: Optional[str] = Field(None, description="Categorization")
    orientation: Optional[str] = Field(None, description="Orientation")
    subject: Optional[str] = Field(None, description="Patient or Participant or Subject")
    sort_keys: Optional[str] = Field(None, description="Sort keys")
    arm_prog: Optional[str] = Field(None, description="ARM Procedure")
    ta: Optional[str] = Field(None, description="Therapeutic Area")


class PlannedOutputsCreate(PlannedOutputsBase):
    pass


class PlannedOutputsUpdate(PlannedOutputsBase):
    pass


class PlannedOutputsInDBBase(PlannedOutputsBase):
    id: int

    class Config:
        orm_mode = True


class PlannedOutputs(PlannedOutputsInDBBase):
    pass


class PlannedOutputsDelete(BaseModel):
    id: int
