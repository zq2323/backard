from pydantic import BaseModel, Field
from typing import Optional


class PlannedAnalysesBase(BaseModel):
    tlf_name: Optional[str] = Field(None, description="TLF name")
    analysis_status: Optional[str] = Field(None, description="Analysis Status")
    anl_name: Optional[str] = Field(None, description="Name")
    analyses_id: Optional[str] = Field(None, description="Analysis ID")
    analysisset_id: Optional[str] = Field(None, description="AnalysisSet ID")
    display_order: Optional[str] = Field(None, description="Output display order")


class PlannedAnalysesCreate(PlannedAnalysesBase):
    pass


class PlannedAnalysesUpdate(PlannedAnalysesBase):
    pass


class PlannedAnalysesInDBBase(PlannedAnalysesBase):
    id: int

    class Config:
        orm_mode = True


class PlannedAnalyses(PlannedAnalysesInDBBase):
    pass


class PlannedAnalysesDelete(BaseModel):
    id: int
