from pydantic import BaseModel, Field
from typing import Optional


class AnalysesBase(BaseModel):
    analyses_id: Optional[str] = Field(None, title="Analyses ID")
    name: Optional[str] = Field(None, title="Name")
    categoryids: Optional[str] = Field(None, title="Category ID")
    reason: Optional[str] = Field(None, title="Reason")
    purpose: Optional[str] = Field(None, title="Purpose")
    analysisset_id: Optional[str] = Field(None, title="AnalysisSet ID")
    groupingid_1: Optional[str] = Field(None, title="Grouping ID 1")
    results_bygrp1: Optional[str] = Field(None, title="Results By Group 1")
    groupingid_2: Optional[str] = Field(None, title="Grouping ID 2")
    results_bygrp2: Optional[str] = Field(None, title="Results By Group 2")
    groupingid_3: Optional[str] = Field(None, title="Grouping ID 3")
    results_bygrp3: Optional[str] = Field(None, title="Results By Group 3")
    groupingid_4: Optional[str] = Field(None, title="Grouping ID 4")
    results_bygrp4: Optional[str] = Field(None, title="Results By Group 4")
    datasubset_id: Optional[str] = Field(None, title="Datasubset ID")
    dataset: Optional[str] = Field(None, title="Analysis Dataset")
    variable: Optional[str] = Field(None, title="Analysis Variable")
    method_id: Optional[str] = Field(None, title="Analysis Method")
    refer_anl1: Optional[str] = Field(None, title="Referenced Analysis 1")
    refer_anl2: Optional[str] = Field(None, title="Referenced Analysis 2")


class AnalysesCreate(AnalysesBase):
    pass


class AnalysesUpdate(AnalysesBase):
    pass


class AnalysesInDBBase(AnalysesBase):
    id: int

    class Config:
        orm_mode = True


class Analyses(AnalysesInDBBase):
    pass


class AnalysesDelete(BaseModel):
    id: int
