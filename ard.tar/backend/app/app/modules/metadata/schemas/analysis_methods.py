from pydantic import BaseModel, Field
from typing import Optional


class AnalysisMethodsBase(BaseModel):
    method_id: Optional[str] = Field(None, title="Method ID")
    description: Optional[str] = Field(None, title="Description")
    stat_id: Optional[str] = Field(None, title="Statistics ID")
    stat_name: str = Field(None, title="Statistics Name")
    link: Optional[str] = Field(None, title="Link")
    stat_label: Optional[str] = Field(None, title="Statistics Label")


class AnalysisMethodsCreate(AnalysisMethodsBase):
    pass


class AnalysisMethodsUpdate(AnalysisMethodsBase):
    pass


class AnalysisMethodsInDBBase(AnalysisMethodsBase):
    id: int

    class Config:
        orm_mode = True


class AnalysisMethods(AnalysisMethodsInDBBase):
    pass


class AnalysisMethodsDelete(BaseModel):
    id: int
