from pydantic import BaseModel, Field
from typing import Optional


class AnalysisGroupingsBase(BaseModel):
    grouping_type: Optional[str] = Field(None, title="Grouping Type")
    Anl_groupingid: Optional[str] = Field(None, title="Analysis Grouping ID")
    label: Optional[str] = Field(None, title="Label")
    grp_var: Optional[str] = Field(None, title="Grouping Variable")
    data_driven: Optional[str] = Field(None, title="Data Driven")
    analysis_status: Optional[str] = Field(None, title="Analysis Status")
    group_label: Optional[str] = Field(None, title="Group label")
    group_level: Optional[str] = Field(None, title="group_level")
    group_logical: Optional[str] = Field(None, title="group_logical")
    group__dataset: Optional[str] = Field(None, title="group__dataset")
    group_variable: Optional[str] = Field(None, title="group_variable")
    group_comparator: Optional[str] = Field(None, title="group_comparator")
    group_value: Optional[str] = Field(None, title="group_value")


class AnalysisGroupingsCreate(AnalysisGroupingsBase):
    pass


class AnalysisGroupingsUpdate(AnalysisGroupingsBase):
    pass


class AnalysisGroupingsInDBBase(AnalysisGroupingsBase):
    id: int

    class Config:
        orm_mode = True


class AnalysisGroupings(AnalysisGroupingsInDBBase):
    pass


class AnalysisGroupingsDelete(BaseModel):
    id: int
