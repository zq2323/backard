from pydantic import BaseModel, Field
from typing import Optional


class AnalysisSetsBase(BaseModel):
    analysisset_id: Optional[str] = Field(None, title="AnalysisSets ID")
    label: Optional[str] = Field(None, title="Label")
    level: Optional[str] = Field(None, title="Level")
    order: Optional[str] = Field(None, title="Order")
    logical_operator: Optional[str] = Field(None, title="Logical Operator")
    condition_dataset: Optional[str] = Field(None, title="Condition dataset")
    condition_variable: Optional[str] = Field(None, title="Condition variable")
    condition_comparator: Optional[str] = Field(None, title="Condition comparator")
    condition_value: Optional[str] = Field(None, title="Condition value")
    count_id: Optional[str] = Field(None, title="Count ID")


class AnalysisSetsCreate(AnalysisSetsBase):
    pass


class AnalysisSetsUpdate(AnalysisSetsBase):
    pass


class AnalysisSetsInDBBase(AnalysisSetsBase):
    id: int

    class Config:
        orm_mode = True


class AnalysisSets(AnalysisSetsInDBBase):
    pass


class AnalysisSetsDelete(BaseModel):
    id: int
