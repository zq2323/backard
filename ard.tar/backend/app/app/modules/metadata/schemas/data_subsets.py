from pydantic import BaseModel, Field
from typing import Optional


class DataSubsetsBase(BaseModel):
    tlf_name: Optional[str] = Field(None, title="Table Type")
    datasubset_id: Optional[str] = Field(None, title="DataSubset ID")
    label: Optional[str] = Field(None, title="Label")
    level: Optional[str] = Field(None, title="Level")
    order: Optional[str] = Field(None, title="Order")
    logical_operator: Optional[str] = Field(None, title="Logical Operator")
    condition_dataset: Optional[str] = Field(None, title="Condition dataset")
    condition_variable: Optional[str] = Field(None, title="Condition variable")
    condition_comparator: Optional[str] = Field(None, title="Condition comparator")
    condition_value: Optional[str] = Field(None, title="Condition value")
    count_id: Optional[str] = Field(None, title="Count ID")


class DataSubsetsCreate(DataSubsetsBase):
    pass


class DataSubsetsUpdate(DataSubsetsBase):
    pass


class DataSubsetsInDBBase(DataSubsetsBase):
    id: int

    class Config:
        orm_mode = True


class DataSubsets(DataSubsetsInDBBase):
    pass


class DataSubsetsDelete(BaseModel):
    id: int
