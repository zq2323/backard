from typing import Optional

from pydantic import BaseModel, Field


# Pydantic schema for creating a new ColumnMapping record
class ColumnMappingCreate(BaseModel):
    model_name: str = Field(..., description="Model Name")
    actual_name: str = Field(..., description="Actual Name")
    custom_name: str = Field(..., description="Custom Name")


# Pydantic schema for reading ColumnMapping records
class ColumnMapping(BaseModel):
    id: int
    model_name: str
    actual_name: str
    custom_name: str


# Pydantic schema for updating ColumnMapping records
class ColumnMappingUpdate(BaseModel):
    custom_name: Optional[str] = None


# Pydantic schema for deleting ColumnMapping records
class ColumnMappingDelete(BaseModel):
    id: int
