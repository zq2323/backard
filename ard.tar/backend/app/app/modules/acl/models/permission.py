from sqlalchemy import Column, ForeignKey, Integer, String, UniqueConstraint, Index, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime

Base = declarative_base()


class Permission(Base):
    __tablename__ = 'permissions'

    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    guard_name = Column(String(255), nullable=False)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)

    __table_args__ = (
        UniqueConstraint('name', 'guard_name'),
    )


class Role(Base):
    __tablename__ = 'roles'

    id = Column(Integer, primary_key=True)
    team_id = Column(Integer, ForeignKey('teams.id'))
    name = Column(String(255), nullable=False)
    guard_name = Column(String(255), nullable=False)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)

    __table_args__ = (
        UniqueConstraint('team_id', 'name', 'guard_name'),
    )


class ModelHasPermission(Base):
    __tablename__ = 'model_has_permissions'

    permission_id = Column(Integer, ForeignKey('permissions.id'), primary_key=True)
    model_type = Column(String(255), nullable=False)
    model_id = Column(Integer, ForeignKey('models.id'), primary_key=True)

    __table_args__ = (
        Index('model_has_permissions_model_id_model_type_index', 'model_id', 'model_type'),
    )


class ModelHasRole(Base):
    __tablename__ = 'model_has_roles'

    role_id = Column(Integer, ForeignKey('roles.id'), primary_key=True)
    model_type = Column(String(255), nullable=False)
    model_id = Column(Integer, ForeignKey('models.id'), primary_key=True)

    __table_args__ = (
        Index('model_has_roles_model_id_model_type_index', 'model_id', 'model_type'),
    )


class RoleHasPermission(Base):
    __tablename__ = 'role_has_permissions'

    permission_id = Column(Integer, ForeignKey('permissions.id'), primary_key=True)
    role_id = Column(Integer, ForeignKey('roles.id'), primary_key=True)

    __table_args__ = (
        UniqueConstraint('permission_id', 'role_id'),
    )
