from typing import TYPE_CHECKING

from sqlalchemy import Column, ForeignKey, Integer, String, Table
from sqlalchemy.orm import relationship


# if TYPE_CHECKING:
# from .permission import Permission  # noqa: F401
from app.core.database.base_model import Base
from app.core.utility.mixins import AuditMixin

user_has_roles = Table(
    "user_has_roles",
    Base.metadata,
    Column("user_id", ForeignKey("users.id", ondelete='CASCADE')),
    Column("role_id", ForeignKey("roles.id", ondelete='CASCADE')),
)

user_has_permissions = Table(
    "user_has_permissions",
    Base.metadata,
    Column("user_id", ForeignKey("users.id", ondelete='CASCADE')),
    Column("permission_id", ForeignKey("permissions.id", ondelete='CASCADE')),
)

role_has_permissions = Table(
    "role_has_permissions",
    Base.metadata,
    Column("role_id", ForeignKey("roles.id", ondelete='CASCADE')),
    Column("permission_id", ForeignKey("permissions.id", ondelete='CASCADE')),
)


class Role(Base):
    __tablename__ = "roles"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String)
    guard_name = Column(String, default='api')

    permissions = relationship("Permission", secondary=role_has_permissions, backref='roles')
    users = relationship("User", secondary=user_has_roles, backref='roles')

    def __repr__(self) -> str:
        return self.name


class Permission(Base):
    __tablename__ = "permissions"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String)
    guard_name = Column(String, default='api')

    users = relationship("User", secondary=user_has_permissions, backref='permissions')

    def __repr__(self) -> str:
        return self.name
