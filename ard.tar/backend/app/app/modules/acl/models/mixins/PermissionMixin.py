from typing import Union, List


class PermissionMixin(object):

    def givePermissionTo(self, permission: str):
        if permission not in self.permissions:
            self.permissions.append(permission)

    def assignRole(self, role: str):
        if role not in self.roles:
            self.roles.append(role)

    def syncPermissions(self, permissions: List[str]):
        self.permissions = permissions

    def syncRoles(self, roles: List[str]):
        self.roles = roles

    def revokePermissionTo(self, permission: str):
        if permission in self.permissions:
            self.permissions.remove(permission)

    def removeRole(self, role: str):
        if role in self.roles:
            self.roles.remove(role)

    def getPermissionNames(self) -> List[str]:
        return self.permissions

    def getDirectPermissions(self) -> List[str]:
        return self.permissions

    def getAllPermissions(self) -> List[str]:
        return self.permissions

    def getRoleNames(self) -> List[str]:
        return self.roles

    def hasPermissionTo(self, permission: str) -> bool:
        return permission in self.permissions

    def hasAnyPermission(self, permissions: List[str]) -> bool:
        return any(p in self.permissions for p in permissions)

    def hasAllPermissions(self, permissions: List[str]) -> bool:
        return all(p in self.permissions for p in permissions)

    def hasAnyRole(self, roles: List[str]) -> bool:
        return any(r in self.roles for r in roles)

    def hasExactRoles(self, roles: List[str]) -> bool:
        return set(self.roles) == set(roles)

    def can(self, permission: Union[str, List[str]]) -> bool:
        if isinstance(permission, str):
            return self.hasPermissionTo(permission)
        elif isinstance(permission, list):
            return self.hasAllPermissions(permission)
        return False
