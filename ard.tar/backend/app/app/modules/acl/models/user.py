import uuid
from datetime import datetime
from typing import TYPE_CHECKING, List

from sqlalchemy import Boolean, Column, String, Date, DateTime, Integer
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.ext import hybrid

# from sqlalchemy.orm import relationship
from sqlalchemy.orm import relationship

from app.core.database.base_model import Base
from app.core.utility.mixins import AuditMixin
from .mixins import PermissionMixin

if TYPE_CHECKING:
    from .role import Role  # noqa: F401
    # from .permission import Permission  # noqa: F401


class User(Base, AuditMixin):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)
    kc_id = Column(UUID(as_uuid=True), nullable=True, index=True)

    username = Column(String, index=True, unique=True, nullable=True)

    first_name = Column(String, index=True)
    last_name = Column(String, index=True)
    other_names = Column(String, index=False)

    date_of_birth = Column(Date)

    avatar = Column(String)
    cover_photo = Column(String)

    email = Column(String, unique=True, index=True, nullable=False)
    phone = Column(String, unique=True, index=True)

    password = Column(String, nullable=True)

    is_superuser = Column(Boolean(), default=False)

    # e_wise fields
    e_wise_token = Column(String)
    e_wise_token_expiry = Column(DateTime, nullable=True)

    # roles = relationship("Role", back_populates="user_roles")
    # permissions = relationship("Permission", back_populates="user_permissions")
    # items = relationship("Item", back_populates="owner")

    # permissions = relationship("Permission", secondary=user_has_permissions)
    # roles = relationship("Role", secondary=user_has_roles)

    # roles = relationship("Role", secondary="permissions")

    # reviews = relationship("Payroll", backref="reviewed_by")
    # approvals = relationship("Payroll", backref="approved_by")

    # apps = relationship('TealApp', backref='user')

    def __init__(self, roles: List[str], permissions: List[str]):
        self.roles = roles
        self.permissions = permissions

    def __repr__(self) -> str:
        return self.full_name()

    @hybrid.hybrid_property
    def full_name(self) -> str:
        other_names = self.other_names if self.other_names is not None else ''
        return "{first_name} {last_name} {other_names}".format(
            first_name=self.first_name,
            last_name=self.last_name,
            other_names=other_names
        ).strip()

    def to_dict(self):
        data = {}
        for column in self.__table__.columns:
            column_name = column.name
            column_value = getattr(self, column_name)

            if isinstance(column_value, (int, bool)):
                data[column_name] = column_value
            else:
                data[column_name] = str(column_value)

        return data


class PasswordReset(Base):
    __tablename__ = "password_resets"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, nullable=False)
    token = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.now)
    expires_at = Column(DateTime)

# Base2 = registry()
# @Base2.mapped
# @dataclass
# class User2:
#     __tablename__ = "users"
#     __sa_dataclass_metadata_key__ = "sa"
#
#     id: uuid.UUID = field(
#         init=False,
#         default_factory=uuid.uuid4,
#         metadata={"sa": Column(UUID(as_uuid=True), primary_key=True)},
#     )
#     first_name: str = field(
#         metadata={"sa": Column(String(254), index=True)}
#     )
#     last_name: str = field(
#         metadata={"sa": Column(String(254), index=True)}
#     )
#     other_names: str = field(
#         metadata={"sa": Column(String(254), index=True)}
#     )
#     date_of_birth: date = field(
#         metadata={"sa": Column(Date)}
#     )
#     email: str = field(
#         metadata={"sa": Column(String(254), nullable=False, unique=True, index=True)}
#     )
#     password: str = field(metadata={"sa": Column(String(128), nullable=False)})
#
#     def __repr__(self) -> str:
#         return self.full_name()
#
#     @hybrid.hybrid_property
#     def full_name(self) -> str:
#         other_names = self.other_names if self.other_names is not None else ''
#         return "{first_name} {last_name} {other_names}".format(
#             first_name=self.first_name,
#             last_name=self.last_name,
#             other_names=other_names
#         ).strip()
