from passlib.context import CryptContext
from sqlalchemy.orm import Session

from app.modules.acl import schemas, models

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto", bcrypt__rounds=12)


async def create_user(db: Session, data: schemas.UserRequest):
    user = models.User(
        first_name=data.first_name,
        last_name=data.last_name,
        other_names=data.other_names,
        email=data.email,
        password=pwd_context.hash(data.password),
        roles=data.roles)
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


async def update_user(db: Session, id: int, data: schemas.UserRequest):
    user = db.query(models.User).filter(models.User.id == id).first()
    if not user:
        return None
    else:
        user.first_name = data.first_name
        user.last_name = data.last_name
        user.other_names = data.other_names
        user.email = data.email
        db.commit()
        db.refresh(user)
        return user


async def get_users(db: Session):
    return db.query(models.User).all()


async def verify_login(db: Session, data: schemas.UserRequest):
    status = False
    message = None
    user_response = None
    user = db.query(models.User).filter(models.User.email == data.email).first()
    if user:
        if (pwd_context.verify(data.password, user.password)):
            user_response = {
                'id': user.id,
                'email': user.email,
                # 'role': user.roles,
                'role': 'admin',
                'full_name': user.full_name
            }
            status = True
        else:
            message = 'Incorrect Password'
    else:
        message = 'Invalid Login'

    return {
        'status': status,
        'message': message,
        'user_data': user_response,
    }


async def delete_user(db: Session, id: int):
    user = db.query(models.User).filter(models.User.id == id).first()
    if user:
        db.delete(user)
        db.commit()
        return True
    else:
        return False
