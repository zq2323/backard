import uuid
from datetime import date
from typing import Optional, List
from fastapi import Query

from pydantic import BaseModel, EmailStr

# Shared properties
from app.utility import enums
# from .role import RoleResponse


class BaseRequest(BaseModel):
    # may define additional fields or config shared across requests
    pass


class UserRequest(BaseRequest):
    first_name: str
    last_name: str
    other_names: Optional[str] = None

    avatar: Optional[str] = None
    cover_photo: Optional[str] = None

    date_of_birth: Optional[date] = None
    # gender: Optional[enums.GenderEnum] = None

    phone: str = None
    email: EmailStr = None

    password: Optional[str] = None
    # is_active: Optional[bool] = None
    is_superuser: Optional[bool] = None
    e_wise_token: Optional[str] = None


class UserCreate(UserRequest):
    pass


class UserUpdateRequest(UserRequest):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    pass


class BaseResponse(BaseModel):
    # may define additional fields or config shared across responses
    class Config:
        orm_mode = True


class UserResponse(BaseResponse):
    id: uuid.UUID
    username: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    other_names: Optional[str] = None

    full_name: Optional[str] = None

    # avatar: Optional[str] = None
    # cover_photo: Optional[str] = None

    date_of_birth: Optional[date] = None
    # gender: Optional[enums.GenderEnum] = None

    phone: Optional[str] = None
    email: Optional[EmailStr] = None

    is_superuser: Optional[bool] = None
    # roles: Optional[List[RoleResponse]] = None
    # permissions: Optional[List[str]] = None

    created_at: Optional[date] = None
    updated_at: Optional[date] = None


class UserPaginateResponse(BaseResponse):
    data: List[UserResponse]
    page: Optional[int]
    limit: Optional[int]
    frm: Optional[int]
    to: Optional[int]
    total: Optional[int]
    last_page: Optional[int]
