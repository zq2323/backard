import uuid
from typing import Union

from pydantic import BaseModel


class JWTTokenPayload(BaseModel):
    sub: Union[str, int]
    refresh: bool
    issued_at: int
    expires_at: int


class SyncKeycloakUser(BaseModel):
    id: uuid.UUID
    username: str
    first_name: str
    last_name: str
    email: str
    # verified_email: bool


class Message(BaseModel):
    message: str
