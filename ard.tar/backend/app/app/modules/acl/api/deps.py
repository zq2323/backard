
import time
from typing import Union

import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session

from app.core import security
from app.core.config.config_reader import get_config
from app.core.session import get_db
from app.modules.acl import models, schemas

reusable_oauth2 = OAuth2PasswordBearer(
    tokenUrl=f"{get_config('app', 'API_V1_STR')}/login/access-token"
)


async def get_current_user(
        db: Session = Depends(get_db),
        token: str = Depends(reusable_oauth2)
) -> models.User:
    try:
        payload = jwt.decode(
            token, security.SECRET_KEY, algorithms=[security.JWT_ALGORITHM]
        )
    except jwt.DecodeError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    # JWT guarantees payload will be unchanged (and thus valid), no errors here
    token_data = schemas.JWTTokenPayload(**payload)

    if token_data.refresh:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials, cannot use refresh token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    now = int(time.time())
    if now < token_data.issued_at or now > token_data.expires_at:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials, token expired or not yet valid",
            headers={"WWW-Authenticate": "Bearer"},
        )

    user: Union[models.User, None] = db.query(models.User).filter(models.User.id == token_data.sub).first()

    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Unauthorized")
    return user
