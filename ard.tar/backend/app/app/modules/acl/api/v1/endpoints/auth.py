import time
from typing import List, Any, Union

import jwt
from fastapi.encoders import jsonable_encoder
from fastapi.security import OAuth2PasswordRequestForm
from pydantic import ValidationError
from starlette.status import HTTP_404_NOT_FOUND

from app.core import security
from app.core.utility.request_utils import get_keycloak_access_token, request_e_wise_api_token
from app.core.utility.utils import encrypt, split_and_trim, response, determine_e_wise_access
from app.modules.acl import crud, models, schemas
from app.modules.acl.api import deps
from app.modules.acl.api.deps import get_current_user
from app.modules.acl.schemas import SyncKeycloakUser
from app.modules.acl.schemas.security import requests as auth_request, responses as auth_response

from app.core.session import get_db
from fastapi import status, HTTPException, APIRouter, Depends
from sqlalchemy.orm import Session

# from app.modules.reflist.models import RefList

router = APIRouter(prefix='/auth')


@router.post("/access-token", response_model=auth_response.AccessTokenResponse)
async def login_access_token(
        db: Session = Depends(get_db),
        form_data: OAuth2PasswordRequestForm = Depends()
) -> Any:
    """OAuth2 compatible token, get an access token for future requests using username and password"""

    query = db.query(models.User).where(models.User.email == form_data.username)
    user: Union[models.User, None] = query.first()

    if user is None:
        raise HTTPException(status_code=400, detail="Incorrect email or password")

    if not security.verify_password(form_data.password, user.password):
        raise HTTPException(status_code=400, detail="Incorrect email or password")

    user_dict = user.to_dict()
    # user_dict.pop('e_wise_token')
    return security.generate_access_token_response(subject=str(user.id), user=user_dict)


@router.post("/refresh-token", response_model=auth_response.AccessTokenResponse)
async def refresh_token(
        data: auth_request.RefreshTokenRequest,
        db: Session = Depends(get_db),
):
    """OAuth2 compatible token, get an access token for future requests using refresh token"""
    try:
        payload = jwt.decode(
            data.refresh_token,
            security.SECRET_KEY,
            algorithms=[security.JWT_ALGORITHM],
        )
    except (jwt.DecodeError, ValidationError):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Could not validate credentials, unknown error",
        )

    # JWT guarantees payload will be unchanged (and thus valid), no errors here
    token_data = schemas.JWTTokenPayload(**payload)

    if not token_data.refresh:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Could not validate credentials, no refresh token provided",
        )
    now = int(time.time())
    if now < token_data.issued_at or now > token_data.expires_at:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Could not validate credentials, token expired or not yet valid",
        )

    # blacklist token before refresh
    # blacklist_token = BlacklistToken(
    #     token=input.refresh_token,
    #     expires_at=datetime.fromtimestamp(token_data.expires_at)
    # )
    # session.add(blacklist_token)
    # db.commit()

    query = db.query(models.User).where(models.User.id == token_data.sub)
    user: Union[models.User, None] = query.first()

    if user is None:
        raise HTTPException(status_code=HTTP_404_NOT_FOUND, detail="User not found")

    user_dict = user.to_dict()
    # user_dict.pop('e_wise_token')
    return security.generate_access_token_response(str(user.id), user=user_dict)


@router.get("/user", response_model=schemas.UserResponse)
async def read_current_user(
        current_user: models.User = Depends(deps.get_current_user),
):
    """Get current user"""

    permissions = []
    for role in current_user.roles:
        if role.permissions:
            permissions.extend([permission.name for permission in role.permissions])

    current_user = jsonable_encoder(current_user)

    # remove duplicate permissions & set permissions
    current_user['permissions'] = list(set(permissions))

    # set full_name
    current_user['full_name'] = "{first_name} {last_name} {other_names}".format(
        first_name=current_user['first_name'],
        last_name=current_user['last_name'],
        other_names=current_user['other_names'] if current_user['other_names'] is not None else ''
    ).strip()

    del current_user['created_at']
    del current_user['updated_at']

    current_user = schemas.UserResponse(**current_user)

    return current_user


@router.get('/user/permissions')
async def get_permissions(
        db: Session = Depends(get_db)
):
    # dummy repository data
    repositories = [
        {
            'name': "FMC01 / FMS01 / CSR",
            'id': 1694406,
            'isOwner': True,
            'isWriteAccess': True,
            'isFavorite': True,
        }, {
            'name': "FMC03 / FMS03 / CSR",
            'id': 2345678,
            'isOwner': False,
            'isWriteAccess': True,
            'isFavorite': False,
        }, {
            'name': "FMC02 / FMS02 / CSR",
            'id': 3456789,
            'isOwner': True,
            'isWriteAccess': False,
            'isFavorite': True,
        }, {
            'name': "FMC04 / FMS04 / CSR",
            'id': 34567894,
            'isOwner': False,
            'isWriteAccess': False,
            'isFavorite': False,
        },
    ]

    # for repository in repositories:
    #     compound, study, analysis, = split_and_trim(repository['name'])
    #     name = repository['name']
    #     # check if ref_list with the provided name exists
    #     ref_list_obj = (
    #         db.query(RefList.name)
    #             .filter_by(name=name, is_triplet=True).first()
    #     )
    #
    #     # create ref_list if doesn't exist
    #     if not ref_list_obj:
    #         ref_list_obj = RefList(
    #             name=repository['name'],
    #             study=study,
    #             compound=compound,
    #             analysis=analysis,
    #             is_triplet=True
    #         )
    #         db.add(ref_list_obj)

    db.commit()

    return response(data=determine_e_wise_access(repositories))


# @router.get('/users', response_model=List[schemas.UserResponse], status_code=200)
# async def get_users(db: Session = Depends(get_db)):
#     users = await crud.get_users(db)
#     return users


@router.post('/sync_keycloak_user', response_model=auth_response.AccessTokenResponse, status_code=200)
async def sync_keycloak_user(
        db: Session = Depends(get_db),
        data: SyncKeycloakUser = Depends(),
):
    user = await kc_sync_user(db, data)

    if user:
        user_dict = user.to_dict()
        # user_dict.pop('e_wise_token')
        return security.generate_access_token_response(str(user.id), user=user_dict)
    else:
        return {"message": "User synchronized successfully"}


async def kc_sync_user(
        db: Session = Depends(get_db),
        data: SyncKeycloakUser = Depends()) -> models.User:
    # Check if a user with the same kc_id or email already exists
    existing_user = db.query(models.User).filter(
        models.User.kc_id == data.id
    ).first()

    if existing_user:
        # User already exists, you can update their information if needed
        existing_user.first_name = data.first_name
        existing_user.last_name = data.last_name
        existing_user.email = data.email
        existing_user.username = data.username
        # Update any other fields if necessary
    else:
        # User doesn't exist, create a new user
        new_user = models.User(
            kc_id=data.id,
            first_name=data.first_name,
            last_name=data.last_name,
            username=data.username,
            email=data.email,

        )
        db.add(new_user)

        existing_user = new_user

    db.commit()

    # Refresh the user object to reflect any changes made during commit
    db.refresh(existing_user)

    return existing_user


@router.get('/get_e_wise_token', status_code=200)
async def get_users(
        db: Session = Depends(get_db),
        current_user: str = Depends(get_current_user)
):
    kc_admin_token = get_keycloak_access_token()
    e_wise_token = request_e_wise_api_token(current_user.username, kc_admin_token)

    current_user.e_wise_token = encrypt(e_wise_token.get('value'))
    current_user.e_wise_token_expiry = e_wise_token.get('expiration_date')

    db.commit()
    db.refresh(current_user)

    return current_user
