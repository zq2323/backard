import uuid
from typing import List, Any

from fastapi import status, APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.crud import __search, __multi_filter, __paginate
from app.core.session import get_db
from app.core.utility.request_utils import get_keycloak_access_token, request_e_wise_api_token
from app.core.utility.utils import response, encrypt
from app.modules.acl import crud, schemas, models
from app.modules.acl.api.deps import get_current_user
from app.modules.acl.models import User
from app.modules.acl.schemas import UserCreate

router = APIRouter()


@router.get('/users', status_code=200)
async def get_users(db: Session = Depends(get_db),
                    page: int = 1,
                    limit: int = 10,
                    search: str = None,
                    filters: Any = None,
                    ):
    query = db.query(models.User)

    # Apply search filter if 'q' parameter is provided
    query = await __search(search, query, models.User)

    # Apply additional filters if provided
    query = await __multi_filter(filters, query, models.User)

    # Fetch paginated results and total count
    items, total = await __paginate(query, limit, page)
    return {
        'items': [schemas.UserResponse.from_orm(item).__dict__ for item in items],
        'total': total,
        'page': page
    }


@router.post("/users/", response_model=schemas.UserResponse)
async def create_user(
        user_data: UserCreate = Depends(),
        db: Session = Depends(get_db)
):
    db_user = User(**user_data.dict())
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user


@router.put('/users/{id}', status_code=status.HTTP_200_OK)
async def update_user(
        id: uuid.UUID,
        update_data: schemas.UserUpdateRequest,
        db: Session = Depends(get_db),
        current_user: str = Depends(get_current_user)
):
    user = db.query(models.User).filter(models.User.id == id).first()
    if not user:
        raise response(message="User not found", status=False)

    for field, value in update_data.dict().items():
        if value is not None and value != "":
            if field == 'e_wise_token':
                value = encrypt(value)

            setattr(user, field, value)

    db.commit()
    db.refresh(user)

    return response(message="User updated successfully.", data=user, status=True)


@router.delete('/users/{id}')
async def delete_user(
        id: int,
        db: Session = Depends(get_db),
        current_user: str = Depends(get_current_user)
):
    success = await crud.delete_user(db, id)
    if success:
        return response(message="User deleted successfully", status=True, data=success)
    else:
        return response(message="User not found", status=False)
