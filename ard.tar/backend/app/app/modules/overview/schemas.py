from typing import Optional

from pydantic import BaseModel


class StudyType(BaseModel):
    id: int
    name: Optional[str] = None
    description: Optional[str] = None

    class Config:
        orm_mode = True


class StudyTypeCreate(BaseModel):
    name: str
    description: Optional[str] = None
