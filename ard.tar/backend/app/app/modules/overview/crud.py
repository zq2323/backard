from passlib.context import CryptContext
from sqlalchemy.orm import Session

from app.modules.study import models, schemas

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def create_study_type_name(db: Session, data: schemas.StudyType):
    study_type = models.StudyType(name=data.name,
                                  description=data.description)
    db.add(study_type)
    db.commit()
    db.refresh(study_type)
    return study_type


def create_study_type(db: Session, data: schemas.StudyTypeCreate):
    study_type = models.StudyType(name=data.name,
                                  description=data.description)
    db.add(study_type)
    db.commit()
    db.refresh(study_type)
    return study_type


async def get_study_types(db: Session):
    return db.query(models.StudyType).all()


async def get_study_type_names(db: Session):
    return db.query(models.StudyType.name).all()


async def update_study_type(db: Session, id: int, study: schemas.StudyType):
    study_type = db.query(models.StudyType).filter(models.StudyType.id == id).first()
    if not study_type:
        return None
    else:
        study_type.name = study.name
        study_type.description = study.description
        db.commit()

        return study_type


async def delete_study_type(db: Session, id: int):
    study_type = db.query(models.StudyType).filter(models.StudyType.id == id).first()
    if study_type:
        db.delete(study_type)
        db.commit()
        return True
    else:
        return False
