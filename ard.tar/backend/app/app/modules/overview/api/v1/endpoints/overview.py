from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.session import get_db

router = APIRouter()


@router.get('/model_item/count', status_code=200)
async def ref_list_output_count(
        db: Session = Depends(get_db)
):
    return {
    }
