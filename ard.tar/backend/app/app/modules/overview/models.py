from sqlalchemy import String, Integer, Column

from app.core.database.base_model import Base
from app.core.utility.mixins import AuditMixin


class StudyType(Base, AuditMixin):
    __tablename__ = 'study_types'
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    description = Column(String, nullable=True)
