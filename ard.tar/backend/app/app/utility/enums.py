from enum import Enum


# from sqlalchemy import Enum

class RiskAssessment(str, Enum):
    L_l = "L/l"
    L_h = "L/h"
    H_l = "H/l"
    H_h = "H/h"


class QCType(str, Enum):
    BASIC = "BASIC"
    BASIC_O = "BASIC + O"
    BASIC_R = "BASIC + R"


class Roles(str, Enum):
    Admin = "admin"
    User = "User"
    DataSteward = "DataSteward"  # manage global reflists
    Statistician = "Statistician"  # Edit reflists for Triplets, Criticality assessment
    LeadProgrammer = "Lead Programmer"  # Assign programmers to reflists
    Programmer = "Programmer"  # Assignee for programmer / QC Programmer
