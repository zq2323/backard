#! /usr/bin/env bash

# Let the DB start
python /app/app/backend_pre_start.py

# Create initial migration
#alembic revision --autogenerate -m "v0"

# Run migrations
alembic upgrade head

# Create initial data in DB
python /app/app/initial_data.py
